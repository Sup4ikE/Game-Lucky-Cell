using System;
using System.Diagnostics.Eventing.Reader;

namespace HW_GameLuckyCell
{
    public partial class Form1 : Form
    {
        private int randomNumber;
        private int counter = 0;

        public Form1()
        {
            InitializeComponent();
            InitializeRandomNumber();
        }

        private void InitializeRandomNumber()
        {
            Random random = new Random();
            randomNumber = random.Next(1, 50); 
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            foreach (Control control in this.Controls)
            {
                if (control is Button button)
                {
                    button.MouseEnter += Button_MouseEventHover;
                    button.MouseLeave += Button_MouseEventLeave;
                    button.Click += Button_MouseEventClick;
                }
            }
        }

        private void Button_MouseEventHover(object sender, EventArgs e)
        {
            Button button = sender as Button;

            if (button != null)
            {
                if (button.ClientRectangle.Contains(button.PointToClient(Cursor.Position)) && button.BackColor != System.Drawing.Color.Red && button.BackColor != System.Drawing.Color.Green)
                {
                    button.BackColor = System.Drawing.Color.Blue;
                }
            }
        }

        private void Button_MouseEventLeave(object sender, EventArgs e)
        {
            Button button = sender as Button;

            if (button != null)
            {
                if (button.ClientRectangle.Contains(button.PointToClient(Cursor.Position)))
                {
                   
                }
                else
                {
                    if (button.BackColor == System.Drawing.Color.Blue) 
                    {
                       button.BackColor = System.Drawing.Color.White;
                    }
                }
            }
        }

        private void Button_MouseEventClick(object sender, EventArgs e)
        {
            Button button = sender as Button;

            if (button != null)
            {
                int buttonNumber;
                if (int.TryParse(button.Tag.ToString(), out buttonNumber))
                {
                    if (buttonNumber == randomNumber)
                    {
                        button.BackColor = System.Drawing.Color.Green;
                        button.Text = counter.ToString();
                        MessageBox.Show("You won!");
                        DialogResult result = MessageBox.Show("Restart?", "Restart?", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
                        if (result == DialogResult.Yes)
                        {
                            Application.Restart();
                        }
                        else 
                        {

                        }
                    }
                    else if (button.BackColor == System.Drawing.Color.Red) 
                    {

                    }
                    else
                    {
                        button.BackColor = System.Drawing.Color.Red;
                        counter++;
                    }
                }
            }
        }
    }
}