﻿namespace HW_GameLuckyCell
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            button5 = new Button();
            button6 = new Button();
            button7 = new Button();
            button8 = new Button();
            button9 = new Button();
            button10 = new Button();
            button11 = new Button();
            button12 = new Button();
            button13 = new Button();
            button14 = new Button();
            button15 = new Button();
            button16 = new Button();
            button17 = new Button();
            button18 = new Button();
            button19 = new Button();
            button20 = new Button();
            button21 = new Button();
            button22 = new Button();
            button23 = new Button();
            button24 = new Button();
            button25 = new Button();
            button26 = new Button();
            button27 = new Button();
            button28 = new Button();
            button29 = new Button();
            button30 = new Button();
            button31 = new Button();
            button32 = new Button();
            button33 = new Button();
            button34 = new Button();
            button35 = new Button();
            button36 = new Button();
            button37 = new Button();
            button38 = new Button();
            button39 = new Button();
            button40 = new Button();
            button41 = new Button();
            button42 = new Button();
            label1 = new Label();
            button43 = new Button();
            button44 = new Button();
            button45 = new Button();
            button46 = new Button();
            button47 = new Button();
            button48 = new Button();
            button49 = new Button();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Location = new Point(113, 35);
            button1.Name = "button1";
            button1.Size = new Size(75, 52);
            button1.TabIndex = 0;
            button1.Tag = "1";
            button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            button2.Location = new Point(194, 35);
            button2.Name = "button2";
            button2.Size = new Size(75, 52);
            button2.TabIndex = 1;
            button2.Tag = "2";
            button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            button3.Location = new Point(275, 35);
            button3.Name = "button3";
            button3.Size = new Size(75, 52);
            button3.TabIndex = 2;
            button3.Tag = "3";
            button3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            button4.Location = new Point(356, 35);
            button4.Name = "button4";
            button4.Size = new Size(75, 52);
            button4.TabIndex = 3;
            button4.Tag = "4";
            button4.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            button5.Location = new Point(437, 35);
            button5.Name = "button5";
            button5.Size = new Size(75, 52);
            button5.TabIndex = 4;
            button5.Tag = "5";
            button5.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            button6.Location = new Point(518, 35);
            button6.Name = "button6";
            button6.Size = new Size(75, 52);
            button6.TabIndex = 5;
            button6.Tag = "6";
            button6.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            button7.Location = new Point(599, 35);
            button7.Name = "button7";
            button7.Size = new Size(75, 52);
            button7.TabIndex = 6;
            button7.Tag = "7";
            button7.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            button8.Location = new Point(113, 93);
            button8.Name = "button8";
            button8.Size = new Size(75, 52);
            button8.TabIndex = 7;
            button8.Tag = "8";
            button8.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            button9.Location = new Point(194, 93);
            button9.Name = "button9";
            button9.Size = new Size(75, 52);
            button9.TabIndex = 8;
            button9.Tag = "9";
            button9.UseVisualStyleBackColor = true;
            // 
            // button10
            // 
            button10.Location = new Point(275, 93);
            button10.Name = "button10";
            button10.Size = new Size(75, 52);
            button10.TabIndex = 9;
            button10.Tag = "10";
            button10.UseVisualStyleBackColor = true;
            // 
            // button11
            // 
            button11.Location = new Point(356, 96);
            button11.Name = "button11";
            button11.Size = new Size(75, 49);
            button11.TabIndex = 10;
            button11.Tag = "11";
            button11.UseVisualStyleBackColor = true;
            // 
            // button12
            // 
            button12.Location = new Point(437, 96);
            button12.Name = "button12";
            button12.Size = new Size(75, 49);
            button12.TabIndex = 11;
            button12.Tag = "12";
            button12.UseVisualStyleBackColor = true;
            // 
            // button13
            // 
            button13.Location = new Point(518, 93);
            button13.Name = "button13";
            button13.Size = new Size(75, 52);
            button13.TabIndex = 12;
            button13.Tag = "13";
            button13.UseVisualStyleBackColor = true;
            // 
            // button14
            // 
            button14.Location = new Point(599, 96);
            button14.Name = "button14";
            button14.Size = new Size(75, 49);
            button14.TabIndex = 13;
            button14.Tag = "14";
            button14.UseVisualStyleBackColor = true;
            // 
            // button15
            // 
            button15.Location = new Point(113, 151);
            button15.Name = "button15";
            button15.Size = new Size(75, 52);
            button15.TabIndex = 14;
            button15.Tag = "15";
            button15.UseVisualStyleBackColor = true;
            // 
            // button16
            // 
            button16.Location = new Point(194, 151);
            button16.Name = "button16";
            button16.Size = new Size(75, 52);
            button16.TabIndex = 15;
            button16.Tag = "16";
            button16.UseVisualStyleBackColor = true;
            // 
            // button17
            // 
            button17.Location = new Point(275, 151);
            button17.Name = "button17";
            button17.Size = new Size(75, 52);
            button17.TabIndex = 16;
            button17.Tag = "17";
            button17.UseVisualStyleBackColor = true;
            // 
            // button18
            // 
            button18.Location = new Point(356, 151);
            button18.Name = "button18";
            button18.Size = new Size(75, 52);
            button18.TabIndex = 17;
            button18.Tag = "18";
            button18.UseVisualStyleBackColor = true;
            // 
            // button19
            // 
            button19.Location = new Point(441, 151);
            button19.Name = "button19";
            button19.Size = new Size(75, 52);
            button19.TabIndex = 18;
            button19.Tag = "19";
            button19.UseVisualStyleBackColor = true;
            // 
            // button20
            // 
            button20.Location = new Point(522, 151);
            button20.Name = "button20";
            button20.Size = new Size(75, 52);
            button20.TabIndex = 19;
            button20.Tag = "20";
            button20.UseVisualStyleBackColor = true;
            // 
            // button21
            // 
            button21.Location = new Point(599, 151);
            button21.Name = "button21";
            button21.Size = new Size(75, 52);
            button21.TabIndex = 20;
            button21.Tag = "21";
            button21.UseVisualStyleBackColor = true;
            // 
            // button22
            // 
            button22.Location = new Point(599, 209);
            button22.Name = "button22";
            button22.Size = new Size(75, 52);
            button22.TabIndex = 27;
            button22.Tag = "28";
            button22.UseVisualStyleBackColor = true;
            // 
            // button23
            // 
            button23.Location = new Point(522, 209);
            button23.Name = "button23";
            button23.Size = new Size(75, 52);
            button23.TabIndex = 26;
            button23.Tag = "27";
            button23.UseVisualStyleBackColor = true;
            // 
            // button24
            // 
            button24.Location = new Point(441, 209);
            button24.Name = "button24";
            button24.Size = new Size(75, 52);
            button24.TabIndex = 25;
            button24.Tag = "26";
            button24.UseVisualStyleBackColor = true;
            // 
            // button25
            // 
            button25.Location = new Point(356, 209);
            button25.Name = "button25";
            button25.Size = new Size(75, 52);
            button25.TabIndex = 24;
            button25.Tag = "25";
            button25.UseVisualStyleBackColor = true;
            // 
            // button26
            // 
            button26.Location = new Point(275, 209);
            button26.Name = "button26";
            button26.Size = new Size(75, 52);
            button26.TabIndex = 23;
            button26.Tag = "24";
            button26.UseVisualStyleBackColor = true;
            // 
            // button27
            // 
            button27.Location = new Point(194, 209);
            button27.Name = "button27";
            button27.Size = new Size(75, 52);
            button27.TabIndex = 22;
            button27.Tag = "23";
            button27.UseVisualStyleBackColor = true;
            // 
            // button28
            // 
            button28.Location = new Point(113, 209);
            button28.Name = "button28";
            button28.Size = new Size(75, 52);
            button28.TabIndex = 21;
            button28.Tag = "22";
            button28.UseVisualStyleBackColor = true;
            // 
            // button29
            // 
            button29.Location = new Point(599, 267);
            button29.Name = "button29";
            button29.Size = new Size(75, 52);
            button29.TabIndex = 34;
            button29.Tag = "35";
            button29.UseVisualStyleBackColor = true;
            // 
            // button30
            // 
            button30.Location = new Point(522, 267);
            button30.Name = "button30";
            button30.Size = new Size(75, 52);
            button30.TabIndex = 33;
            button30.Tag = "34";
            button30.UseVisualStyleBackColor = true;
            // 
            // button31
            // 
            button31.Location = new Point(441, 267);
            button31.Name = "button31";
            button31.Size = new Size(75, 52);
            button31.TabIndex = 32;
            button31.Tag = "33";
            button31.UseVisualStyleBackColor = true;
            // 
            // button32
            // 
            button32.Location = new Point(356, 267);
            button32.Name = "button32";
            button32.Size = new Size(75, 52);
            button32.TabIndex = 31;
            button32.Tag = "32";
            button32.UseVisualStyleBackColor = true;
            // 
            // button33
            // 
            button33.Location = new Point(275, 267);
            button33.Name = "button33";
            button33.Size = new Size(75, 52);
            button33.TabIndex = 30;
            button33.Tag = "31";
            button33.UseVisualStyleBackColor = true;
            // 
            // button34
            // 
            button34.Location = new Point(194, 267);
            button34.Name = "button34";
            button34.Size = new Size(75, 52);
            button34.TabIndex = 29;
            button34.Tag = "30";
            button34.UseVisualStyleBackColor = true;
            // 
            // button35
            // 
            button35.Location = new Point(113, 267);
            button35.Name = "button35";
            button35.Size = new Size(75, 52);
            button35.TabIndex = 28;
            button35.Tag = "29";
            button35.UseVisualStyleBackColor = true;
            // 
            // button36
            // 
            button36.Location = new Point(599, 325);
            button36.Name = "button36";
            button36.Size = new Size(75, 52);
            button36.TabIndex = 41;
            button36.Tag = "42";
            button36.UseVisualStyleBackColor = true;
            // 
            // button37
            // 
            button37.Location = new Point(522, 325);
            button37.Name = "button37";
            button37.Size = new Size(75, 52);
            button37.TabIndex = 40;
            button37.Tag = "41";
            button37.UseVisualStyleBackColor = true;
            // 
            // button38
            // 
            button38.Location = new Point(441, 325);
            button38.Name = "button38";
            button38.Size = new Size(75, 52);
            button38.TabIndex = 39;
            button38.Tag = "40";
            button38.UseVisualStyleBackColor = true;
            // 
            // button39
            // 
            button39.Location = new Point(356, 325);
            button39.Name = "button39";
            button39.Size = new Size(75, 52);
            button39.TabIndex = 38;
            button39.Tag = "39";
            button39.UseVisualStyleBackColor = true;
            // 
            // button40
            // 
            button40.Location = new Point(275, 325);
            button40.Name = "button40";
            button40.Size = new Size(75, 52);
            button40.TabIndex = 37;
            button40.Tag = "38";
            button40.UseVisualStyleBackColor = true;
            // 
            // button41
            // 
            button41.Location = new Point(194, 325);
            button41.Name = "button41";
            button41.Size = new Size(75, 52);
            button41.TabIndex = 36;
            button41.Tag = "37";
            button41.UseVisualStyleBackColor = true;
            // 
            // button42
            // 
            button42.Location = new Point(113, 325);
            button42.Name = "button42";
            button42.Size = new Size(75, 52);
            button42.TabIndex = 35;
            button42.Tag = "36";
            button42.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(345, 9);
            label1.Name = "label1";
            label1.Size = new Size(95, 15);
            label1.TabIndex = 42;
            label1.Text = "Game Lucky Cell";
            // 
            // button43
            // 
            button43.Location = new Point(599, 383);
            button43.Name = "button43";
            button43.Size = new Size(75, 52);
            button43.TabIndex = 49;
            button43.Tag = "49";
            button43.UseVisualStyleBackColor = true;
            // 
            // button44
            // 
            button44.Location = new Point(522, 383);
            button44.Name = "button44";
            button44.Size = new Size(75, 52);
            button44.TabIndex = 48;
            button44.Tag = "48";
            button44.UseVisualStyleBackColor = true;
            // 
            // button45
            // 
            button45.Location = new Point(441, 383);
            button45.Name = "button45";
            button45.Size = new Size(75, 52);
            button45.TabIndex = 47;
            button45.Tag = "47";
            button45.UseVisualStyleBackColor = true;
            // 
            // button46
            // 
            button46.Location = new Point(356, 383);
            button46.Name = "button46";
            button46.Size = new Size(75, 52);
            button46.TabIndex = 46;
            button46.Tag = "46";
            button46.UseVisualStyleBackColor = true;
            // 
            // button47
            // 
            button47.Location = new Point(275, 383);
            button47.Name = "button47";
            button47.Size = new Size(75, 52);
            button47.TabIndex = 45;
            button47.Tag = "45";
            button47.UseVisualStyleBackColor = true;
            // 
            // button48
            // 
            button48.Location = new Point(194, 383);
            button48.Name = "button48";
            button48.Size = new Size(75, 52);
            button48.TabIndex = 44;
            button48.Tag = "44";
            button48.UseVisualStyleBackColor = true;
            // 
            // button49
            // 
            button49.Location = new Point(113, 383);
            button49.Name = "button49";
            button49.Size = new Size(75, 52);
            button49.TabIndex = 43;
            button49.Tag = "43";
            button49.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(button43);
            Controls.Add(button44);
            Controls.Add(button45);
            Controls.Add(button46);
            Controls.Add(button47);
            Controls.Add(button48);
            Controls.Add(button49);
            Controls.Add(label1);
            Controls.Add(button36);
            Controls.Add(button37);
            Controls.Add(button38);
            Controls.Add(button39);
            Controls.Add(button40);
            Controls.Add(button41);
            Controls.Add(button42);
            Controls.Add(button29);
            Controls.Add(button30);
            Controls.Add(button31);
            Controls.Add(button32);
            Controls.Add(button33);
            Controls.Add(button34);
            Controls.Add(button35);
            Controls.Add(button22);
            Controls.Add(button23);
            Controls.Add(button24);
            Controls.Add(button25);
            Controls.Add(button26);
            Controls.Add(button27);
            Controls.Add(button28);
            Controls.Add(button21);
            Controls.Add(button20);
            Controls.Add(button19);
            Controls.Add(button18);
            Controls.Add(button17);
            Controls.Add(button16);
            Controls.Add(button15);
            Controls.Add(button14);
            Controls.Add(button13);
            Controls.Add(button12);
            Controls.Add(button11);
            Controls.Add(button10);
            Controls.Add(button9);
            Controls.Add(button8);
            Controls.Add(button7);
            Controls.Add(button6);
            Controls.Add(button5);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
        private Button button5;
        private Button button6;
        private Button button7;
        private Button button8;
        private Button button9;
        private Button button10;
        private Button button11;
        private Button button12;
        private Button button13;
        private Button button14;
        private Button button15;
        private Button button16;
        private Button button17;
        private Button button18;
        private Button button19;
        private Button button20;
        private Button button21;
        private Button button22;
        private Button button23;
        private Button button24;
        private Button button25;
        private Button button26;
        private Button button27;
        private Button button28;
        private Button button29;
        private Button button30;
        private Button button31;
        private Button button32;
        private Button button33;
        private Button button34;
        private Button button35;
        private Button button36;
        private Button button37;
        private Button button38;
        private Button button39;
        private Button button40;
        private Button button41;
        private Button button42;
        private Label label1;
        private Button button43;
        private Button button44;
        private Button button45;
        private Button button46;
        private Button button47;
        private Button button48;
        private Button button49;
    }
}